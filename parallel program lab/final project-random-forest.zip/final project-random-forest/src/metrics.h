#ifndef CPP_2020_RANDOM_FOREST_METRICS_H
#define CPP_2020_RANDOM_FOREST_METRICS_H

#include "decision_tree.h"


double accuracy_score(target_type& y_true, target_type& y_pred);

#endif //CPP_2020_RANDOM_FOREST_METRICS_H
